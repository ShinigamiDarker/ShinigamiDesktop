package com.zyon.shinigamidesktop

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var darkMode = false
    private var wallpaperChoice = 0
    private var leftAlignedTaskbar = false
    private var accent = Color.rgb(0, 103, 192)
    private lateinit var root: FrameLayout
    private lateinit var desktopLayer: FrameLayout
    private var startPanel: View? = null
    private var appPanel: View? = null
    private var quickPanel: View? = null
    private val desktopWindows = mutableListOf<View>()
    private var contextMenuView: View? = null
    private var clockView: TextView? = null
    private val white get() = Color.WHITE
    private val ink get() = if (darkMode) Color.WHITE else Color.rgb(28, 35, 45)
    private val surface get() = if (darkMode) Color.rgb(31, 42, 57) else Color.rgb(244, 248, 253)
    private val surface2 get() = if (darkMode) Color.rgb(47, 60, 77) else Color.rgb(229, 237, 247)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 31, 58)
        window.navigationBarColor = Color.rgb(18, 37, 62)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        val prefs = getSharedPreferences("desktop_preferences", MODE_PRIVATE)
        darkMode = prefs.getBoolean("dark_mode", false)
        wallpaperChoice = prefs.getInt("wallpaper", 0).coerceIn(0, 2)
        leftAlignedTaskbar = prefs.getBoolean("taskbar_left", false)
        accent = prefs.getInt("accent", Color.rgb(0, 103, 192))
        buildDesktop()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.isMetaPressed) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_E -> { openFiles(); return true }
                KeyEvent.KEYCODE_I -> { showSettings(); return true }
                KeyEvent.KEYCODE_S -> { showSearch(); return true }
                KeyEvent.KEYCODE_D -> { closeStart(); closeApps(); closeQuickPanel(); return true }
            }
        }
        if (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_ESCAPE) {
            when { startPanel != null -> { closeStart(); return true }; appPanel != null -> { closeApps(); return true }; quickPanel != null -> { closeQuickPanel(); return true } }
        }
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        when {
            startPanel != null -> closeStart()
            appPanel != null -> closeApps()
            quickPanel != null -> closeQuickPanel()
            else -> super.onBackPressed()
        }
    }

    private fun buildDesktop() {
        root = FrameLayout(this)
        val wallpaper = WallpaperView()
        wallpaper.setOnLongClickListener { showDesktopMenu(); true }
        wallpaper.setOnContextClickListener { showDesktopMenu(); true }
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        desktopLayer = FrameLayout(this)
        root.addView(desktopLayer, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val shortcuts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setPadding(dp(12), dp(16), dp(12), dp(12))
        }
        val shortcutLp = FrameLayout.LayoutParams(dp(98), -2, Gravity.TOP or Gravity.START)
        desktopLayer.addView(shortcuts, shortcutLp)
        desktopShortcut(shortcuts, "▣", "Este dispositivo", Color.rgb(112, 178, 235)) { showDeviceInfo() }
        desktopShortcut(shortcuts, "📁", "Explorador de\nArquivos", Color.rgb(255, 190, 55)) { openFiles() }
        desktopShortcut(shortcuts, "🌐", "Brave", Color.rgb(255, 110, 65)) { openBrave("https://search.brave.com") }
        desktopShortcut(shortcuts, "🌊", "Microsoft Edge", Color.rgb(0, 150, 210)) { openEdge("https://www.microsoft.com/edge") }
        desktopShortcut(shortcuts, "♻", "Lixeira", Color.rgb(190, 215, 235)) { showRecycleBin() }

        buildTaskbar()
    }

    private fun buildTaskbar() {
        val bar = FrameLayout(this).apply {
            val drawable = rounded(if (darkMode) Color.argb(232, 28, 39, 53) else Color.argb(235, 239, 245, 251), 0)
            drawable.setStroke(dp(1), if (darkMode) Color.argb(70, 255, 255, 255) else Color.argb(120, 255, 255, 255))
            background = drawable
        }
        val barLp = FrameLayout.LayoutParams(-1, dp(62), Gravity.BOTTOM)
        root.addView(bar, barLp)
        val center = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(5), dp(8), dp(5)) }
        center.background = rounded(if (darkMode) Color.argb(170, 41, 53, 68) else Color.argb(170, 255, 255, 255), 18)
        val centerLp = FrameLayout.LayoutParams(-2, dp(50), if (leftAlignedTaskbar) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER)
        centerLp.leftMargin = dp(8)
        bar.addView(center, centerLp)
        windowsButton(center)
        searchBox(center)
        taskIcon(center, "▦", "Todos os aplicativos", 22f) { showApps() }
        taskIcon(center, "📁", "Explorador de Arquivos", 20f) { openFiles() }
        taskIcon(center, "🌐", "Brave", 20f) { openBrave("https://search.brave.com") }
        taskIcon(center, "🌊", "Microsoft Edge", 20f) { openEdge("https://www.microsoft.com/edge") }
        taskIcon(center, "⚙", "Configurações", 21f) { showSettings() }

        val tray = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(8), dp(4), dp(10), dp(4)); isClickable = true; isFocusable = true; setOnClickListener { toggleQuickPanel() } }
        val trayLp = FrameLayout.LayoutParams(-2, -1, Gravity.END or Gravity.CENTER_VERTICAL)
        bar.addView(tray, trayLp)
        tray.addView(label("⌃  ◉  ◖", 13f, ink, Gravity.CENTER), LinearLayout.LayoutParams(-2, -1))
        tray.addView(label("◔", 17f, ink, Gravity.CENTER), LinearLayout.LayoutParams(dp(28), -1))
        val time = label(clockText(), 11f, ink, Gravity.CENTER)
        time.setLineSpacing(0f, 1f)
        tray.addView(time, LinearLayout.LayoutParams(dp(58), -1))
        clockView = time
        time.postDelayed(object : Runnable {
            override fun run() {
                if (!isFinishing && time.isAttachedToWindow) {
                    time.text = clockText()
                    time.postDelayed(this, 30_000)
                }
            }
        }, 30_000)
        val showDesktop = View(this).apply { background = rounded(Color.argb(90, 120, 140, 160), 0); setOnClickListener { closeStart(); closeApps(); closeQuickPanel() } }
        bar.addView(showDesktop, FrameLayout.LayoutParams(dp(4), -1, Gravity.END))
    }


    private fun windowsButton(parent: LinearLayout) {
        val button = FrameLayout(this).apply {
            isClickable = true; isFocusable = true; contentDescription = "Iniciar"; setOnClickListener { toggleStart() }
            background = rounded(Color.argb(1,255,255,255), 12)
        }
        val logo = GridLayout(this).apply { columnCount = 2; rowCount = 2 }
        val blue = Color.rgb(0, 120, 212)
        repeat(4) {
            logo.addView(View(this).apply { background = rounded(blue, 1) }, GridLayout.LayoutParams().apply { width = dp(9); height = dp(9); setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
        button.addView(logo, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        parent.addView(button, LinearLayout.LayoutParams(dp(43), -1).apply { setMargins(dp(2), 0, dp(2), 0) })
    }

    private fun searchBox(parent: LinearLayout) {
        val search = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (darkMode) Color.argb(85,255,255,255) else Color.rgb(250, 252, 255), 15)
            isClickable = true; isFocusable = true; setOnClickListener { showSearch() }
            setPadding(dp(10), 0, dp(12), 0)
        }
        search.addView(label("⌕", 23f, if (darkMode) white else Color.rgb(65, 77, 92), Gravity.CENTER), LinearLayout.LayoutParams(dp(27), -1))
        search.addView(label("Pesquisar", 12f, if (darkMode) white else Color.rgb(76, 86, 99), Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(dp(74), -1))
        parent.addView(search, LinearLayout.LayoutParams(dp(135), -1).apply { setMargins(dp(3), 0, dp(3), 0) })
    }

    private fun desktopShortcut(parent: LinearLayout, glyph: String, title: String, tint: Int, action: () -> Unit) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(6), dp(3), dp(7)); isClickable = true; isFocusable = true
            setOnClickListener { action() }
            setOnLongClickListener { showShortcutContextMenu(title, action, this); true }
            setOnContextClickListener { showShortcutContextMenu(title, action, this); true }
            isHapticFeedbackEnabled = true
            background = rounded(Color.argb(1,255,255,255), 9)
        }
        val appPackage = when {
            title.contains("Brave", true) -> "com.brave.browser"
            title.contains("Edge", true) -> "com.microsoft.emmx"
            else -> null
        }
        val realIcon = try { appPackage?.let { packageManager.getApplicationIcon(it) } } catch (_: Exception) { null }
        val iconView: View = if (realIcon != null) {
            ImageView(this).apply { setImageDrawable(realIcon); scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(5), dp(5), dp(5), dp(5)); background = rounded(Color.argb(205, 255, 255, 255), 10) }
        } else TextView(this).apply {
            text = glyph; textSize = 28f; gravity = Gravity.CENTER; setTextColor(white)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(tint, adjust(tint, -35))).apply { cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.argb(95,255,255,255)) }
        }
        item.addView(iconView, LinearLayout.LayoutParams(dp(48), dp(46)))
        item.addView(label(title, 11f, white, Gravity.CENTER).apply { setShadowLayer(dp(2).toFloat(), 0f, 1f, Color.BLACK); maxLines = 2 }, LinearLayout.LayoutParams(-1, -2))
        parent.addView(item, LinearLayout.LayoutParams(-1, dp(88)))
    }

    private fun taskIcon(parent: LinearLayout, glyph: String, desc: String, size: Float, action: () -> Unit): TextView {
        val button = TextView(this).apply {
            text = glyph; textSize = size; gravity = Gravity.CENTER; setTextColor(ink); contentDescription = desc; isClickable = true; isFocusable = true
            setOnClickListener { action() }; background = rounded(Color.argb(1,255,255,255), 12)
            setPadding(dp(5), 0, dp(5), 0)
        }
        parent.addView(button, LinearLayout.LayoutParams(dp(if (desc == "Pesquisar") 48 else 43), -1).apply { setMargins(dp(2), 0, dp(2), 0) })
        return button
    }

    private fun toggleStart() {
        if (startPanel != null) { closeStart(); return }
        closeApps(); closeQuickPanel()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(20), dp(22), dp(14))
            background = panelBackground(26)
            elevation = dp(22).toFloat()
        }
        val width = minOf(dp(600), resources.displayMetrics.widthPixels - dp(28))
        val height = minOf(dp(600), resources.displayMetrics.heightPixels - dp(100))
        val lp = FrameLayout.LayoutParams(width, height, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(74) }
        root.addView(box, lp); startPanel = box

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Iniciar", 23f, ink, Gravity.START).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(textButton("•••", 19f, ink) { showPersonalization() }, LinearLayout.LayoutParams(dp(42), dp(38)))
        box.addView(head)
        val search = EditText(this).apply {
            hint = "Pesquisar aplicativos, configurações e documentos"; textSize = 13f; setTextColor(ink); setHintTextColor(if (darkMode) Color.LTGRAY else Color.rgb(100,110,124)); maxLines = 1; setHorizontallyScrolling(true)
            background = rounded(surface2, 14); setPadding(dp(14), 0, dp(14), 0)
        }
        box.addView(search, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(15); bottomMargin = dp(18) })
        val pinnedHead = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        pinnedHead.addView(label("Fixados", 15f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        pinnedHead.addView(textButton("Todos os aplicativos  ›", 11f, ink) { closeStart(); showApps() }.apply { background = rounded(surface2, 8); setPadding(dp(8), dp(5), dp(8), dp(5)) })
        box.addView(pinnedHead)
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val grid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        content.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(14) })
        val pinned = listOf(
            Triple("🌐", "Brave", { openBrave("https://search.brave.com") }),
            Triple("🌊", "Microsoft Edge", { openEdge("https://www.microsoft.com/edge") }),
            Triple("📁", "Explorador de\nArquivos", { openFiles() }),
            Triple("⚙", "Configurações", { showSettings() }),
            Triple("▦", "Aplicativos", { closeStart(); showApps() }),
            Triple("🖼", "Personalização", { showPersonalization() }),
            Triple("🛡", "Segurança", { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }),
            Triple("📶", "Rede e internet", { openNetworkSettings() }),
            Triple("♿", "Acessibilidade", { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        )
        pinned.forEach { (glyph, name, action) ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(3), dp(7), dp(3), dp(7)); isClickable = true; isFocusable = true; setOnClickListener { action() } }
            val icon = TextView(this).apply { text = glyph; textSize = 26f; gravity = Gravity.CENTER; setTextColor(ink); background = rounded(surface2, 13) }
            item.addView(icon, LinearLayout.LayoutParams(dp(48), dp(46)))
            item.addView(label(name, 10.5f, ink, Gravity.CENTER).apply { maxLines = 2 }, LinearLayout.LayoutParams(-1, dp(32)))
            grid.addView(item, GridLayout.LayoutParams().apply { this.width = 0; this.height = dp(88); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(2), dp(2), dp(2), dp(2)) })
        }
        content.addView(label("Recomendados", 15f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(4), 0, dp(8)) })
        val recent = listOf("Continuar de onde parou", "Explorador de Arquivos", "Configurações do dispositivo")
        recent.forEachIndexed { i, name ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)); isClickable = true; setOnClickListener { when(i) { 1 -> openFiles(); 2 -> openSettings(); else -> showApps() } } }
            row.addView(label(listOf("◷", "📁", "⚙")[i], 20f, accent, Gravity.CENTER), LinearLayout.LayoutParams(dp(38), dp(38)))
            row.addView(label(name, 12f, ink, Gravity.START), LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label(if (i == 0) "Recentemente" else "Sistema", 10f, if (darkMode) Color.LTGRAY else Color.GRAY, Gravity.END))
            content.addView(row)
        }
        scroll.addView(content); box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(10), dp(2), 0) }
        footer.addView(label("●", 23f, accent, Gravity.CENTER), LinearLayout.LayoutParams(dp(36), dp(36)))
        footer.addView(label("Usuário", 12f, ink, Gravity.START), LinearLayout.LayoutParams(0, -2, 1f))
        footer.addView(textButton("⏻", 22f, ink) { showPowerMenu() }, LinearLayout.LayoutParams(dp(44), dp(40)))
        box.addView(footer)
        search.addTextChangedListener(Watcher { q ->
            if (q.isNotBlank()) {
                val match = launchableApps().firstOrNull { it.first.contains(q, true) }
                // Keep pinned shortcuts visible; Enter/search action launches the best match or Brave search.
                search.setOnEditorActionListener { _, _, _ -> if (match != null) launchIntent(match.second) else openBrave("https://search.brave.com/search?q=" + Uri.encode(q)); true }
            }
        })
    }

    private fun showApps() {
        closeStart(); closeQuickPanel()
        if (appPanel != null) { closeApps(); return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(14)); background = panelBackground(24); elevation = dp(20).toFloat() }
        val width = minOf(dp(650), resources.displayMetrics.widthPixels - dp(28))
        val height = minOf(dp(620), resources.displayMetrics.heightPixels - dp(90))
        root.addView(box, FrameLayout.LayoutParams(width, height, Gravity.CENTER))
        appPanel = box
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("Todos os aplicativos", 22f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(textButton("✕", 20f, ink) { closeApps() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head)
        val input = EditText(this).apply { hint = "Pesquisar aplicativos"; maxLines = 1; setHorizontallyScrolling(true); textSize = 14f; setTextColor(ink); setHintTextColor(Color.GRAY); background = rounded(surface2, 13); setPadding(dp(13), 0, dp(13), 0) }
        box.addView(input, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(12); bottomMargin = dp(10) })
        val list = ListView(this).apply { divider = null; cacheColorHint = Color.TRANSPARENT; setBackgroundColor(Color.TRANSPARENT) }
        box.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refresh(q: String) {
            val apps = launchableApps().filter { it.first.contains(q, true) }
            list.adapter = object : ArrayAdapter<Pair<String, Intent>>(this, android.R.layout.simple_list_item_1, apps) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val row = convertView as? LinearLayout ?: LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(7), dp(10), dp(7)) }
                    row.removeAllViews()
                    val info = apps[position]
                    row.isClickable = true
                    row.isFocusable = true
                    row.setOnLongClickListener { showAppContextMenu(info.first, info.second, row); true }
                    row.setOnContextClickListener { showAppContextMenu(info.first, info.second, row); true }
                    val pkg = info.second.component?.packageName
                    val icon = ImageView(this@MainActivity)
                    if (pkg != null) try { icon.setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
                    row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(12) })
                    row.addView(label(info.first, 14f, ink, Gravity.START), LinearLayout.LayoutParams(0, -2, 1f))
                    return row
                }
            }
            list.setOnItemClickListener { _, _, position, _ -> launchIntent(apps[position].second) }
        }
        refresh("")
        input.addTextChangedListener(Watcher { refresh(it) })
    }

    private fun toggleQuickPanel() {
        if (quickPanel != null) { closeQuickPanel(); return }
        closeStart(); closeApps()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = panelBackground(22); elevation = dp(20).toFloat() }
        val width = minOf(dp(340), resources.displayMetrics.widthPixels - dp(24))
        val lp = FrameLayout.LayoutParams(width, -2, Gravity.BOTTOM or Gravity.END).apply { bottomMargin = dp(72); rightMargin = dp(10) }
        root.addView(box, lp); quickPanel = box
        box.addView(label("Configurações rápidas", 17f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD })
        val grid = GridLayout(this).apply { columnCount = 2 }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        listOf(Triple("◉", "Wi-Fi", { openNetworkSettings() }), Triple("◖", "Bluetooth", { openNetworkSettings() }), Triple("☾", "Não perturbe", { Toast.makeText(this@MainActivity, "Use as configurações do Android para ajustar notificações.", Toast.LENGTH_SHORT).show() }), Triple("⚙", "Configurações", { closeQuickPanel(); openSettings() })).forEach { (glyph, title, action) ->
            val b = textButton("$glyph   $title", 13f, ink, action).apply { gravity = Gravity.CENTER_VERTICAL; background = rounded(surface2, 12); setPadding(dp(12), 0, dp(8), 0) }
            grid.addView(b, GridLayout.LayoutParams().apply { this.width = 0; this.height = dp(52); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) })
        }
        val seek = SeekBar(this).apply { max = 100; progress = 70; progressTintList = android.content.res.ColorStateList.valueOf(accent) }
        box.addView(label("Brilho", 12f, ink, Gravity.START).apply { setPadding(0, dp(12), 0, 0) })
        box.addView(seek, LinearLayout.LayoutParams(-1, dp(36)))
        box.addView(textButton("Personalização", 13f, accent) { closeQuickPanel(); showPersonalization() }.apply { gravity = Gravity.START })
    }

    private fun showSettings() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            background = panelBackground(24)
        }
        outer.addView(label("Configurações", 25f, ink, Gravity.START).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
        val search = EditText(this).apply {
            hint = "Localizar uma configuração"; textSize = 13f; maxLines = 1
            setTextColor(ink); setHintTextColor(Color.GRAY); setPadding(dp(14), 0, dp(14), 0)
            background = rounded(surface2, 12)
        }
        outer.addView(search, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        data class SettingItem(val icon: String, val title: String, val description: String, val action: () -> Unit)
        val items = listOf(
            SettingItem("🖼", "Personalização", "Plano de fundo, cores, modo claro ou escuro", { showPersonalization() }),
            SettingItem("▤", "Sistema", "Tela, som, notificações e informações do tablet", { openAndroidSetting(Settings.ACTION_SETTINGS) }),
            SettingItem("◉", "Bluetooth e dispositivos", "Bluetooth e dispositivos conectados", { openAndroidSetting(Settings.ACTION_BLUETOOTH_SETTINGS) }),
            SettingItem("⌁", "Rede e Internet", "Wi-Fi, conexões e rede", { openNetworkSettings() }),
            SettingItem("▦", "Aplicativos", "Aplicativos instalados e aplicativos padrão", { openAndroidSetting(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS) }),
            SettingItem("◷", "Hora e idioma", "Data, hora e idioma do sistema", { openAndroidSetting(Settings.ACTION_DATE_SETTINGS) }),
            SettingItem("♿", "Acessibilidade", "Tamanho do texto, leitor de tela e controles", { openAndroidSetting(Settings.ACTION_ACCESSIBILITY_SETTINGS) }),
            SettingItem("♢", "Privacidade e segurança", "Permissões e configurações de segurança", { openAndroidSetting(Settings.ACTION_SECURITY_SETTINGS) }),
            SettingItem("↻", "Atualizações do sistema", "Verifique atualizações nas configurações do Android", { openAndroidSetting(Settings.ACTION_SETTINGS) })
        )
        fun render(filter: String = "") {
            list.removeAllViews()
            items.filter { it.title.contains(filter, true) || it.description.contains(filter, true) }.forEach { item ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10)); background = rounded(surface2, 14)
                    isClickable = true; isFocusable = true; setOnClickListener { item.action() }
                }
                row.setOnContextClickListener { showSimpleContextMenu(item.title, item.action, row); true }
                row.addView(label(item.icon, 24f, accent, Gravity.CENTER), LinearLayout.LayoutParams(dp(44), dp(48)))
                val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
                texts.addView(label(item.title, 14f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD })
                texts.addView(label(item.description, 11f, if (darkMode) Color.LTGRAY else Color.DKGRAY, Gravity.START).apply { setPadding(0, dp(3), 0, 0) })
                row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(label("›", 24f, ink, Gravity.CENTER), LinearLayout.LayoutParams(dp(24), dp(42)))
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
        }
        render()
        search.addTextChangedListener(Watcher { render(it) })
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(textButton("Configurações completas do Android  ›", 13f, accent) { openSettings() }.apply { gravity = Gravity.START; setPadding(dp(4), dp(12), dp(4), dp(8)) })
        showDesktopWindow("Configurações", outer, .88f, .84f)
    }

    private fun openAndroidSetting(action: String) {
        try { startActivity(Intent(action)) } catch (_: Exception) { openSettings() }
    }

    private fun showPersonalization() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(8)); background = panelBackground(20) }
        val title = label("Personalização", 21f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD }
        box.addView(title)
        box.addView(label("Plano de fundo", 13f, ink, Gravity.START).apply { setPadding(0, dp(14), 0, dp(6)) })
        val wallpapers = GridLayout(this).apply { columnCount = 3 }
        val names = listOf("Bloom azul", "Aurora", "Noite")
        val colors = listOf(Color.rgb(0, 103, 192), Color.rgb(19, 125, 135), Color.rgb(30, 38, 70))
        names.forEachIndexed { i, name ->
            val b = TextView(this).apply { text = if (wallpaperChoice == i) "✓\n$name" else "\n$name"; textSize = 12f; setTextColor(white); gravity = Gravity.CENTER; background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(colors[i], adjust(colors[i], -65))).apply { cornerRadius = dp(12).toFloat(); setStroke(dp(if (wallpaperChoice == i) 3 else 1), if (wallpaperChoice == i) Color.WHITE else Color.argb(80,255,255,255)) }; setOnClickListener { wallpaperChoice = i; savePreferences(); buildDesktop(); showPersonalization() } }
            wallpapers.addView(b, GridLayout.LayoutParams().apply { width = 0; height = dp(72); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(3), dp(3), dp(3), dp(3)) })
        }
        box.addView(wallpapers, LinearLayout.LayoutParams(-1, -2))
        box.addView(label("Modo", 13f, ink, Gravity.START).apply { setPadding(0, dp(14), 0, dp(6)) })
        val mode = textButton(if (darkMode) "☾  Escuro  ·  tocar para usar modo claro" else "☀  Claro  ·  tocar para usar modo escuro", 13f, ink) { darkMode = !darkMode; savePreferences(); buildDesktop(); showPersonalization() }
        mode.background = rounded(surface2, 12); box.addView(mode, LinearLayout.LayoutParams(-1, dp(46)))
        box.addView(label("Alinhamento da barra de tarefas", 13f, ink, Gravity.START).apply { setPadding(0, dp(14), 0, dp(6)) })
        val align = textButton(if (leftAlignedTaskbar) "À esquerda  ·  tocar para centralizar" else "Centralizado  ·  tocar para alinhar à esquerda", 13f, ink) { leftAlignedTaskbar = !leftAlignedTaskbar; savePreferences(); buildDesktop(); showPersonalization() }
        align.background = rounded(surface2, 12); box.addView(align, LinearLayout.LayoutParams(-1, dp(46)))
        box.addView(label("Cor de destaque", 13f, ink, Gravity.START).apply { setPadding(0, dp(14), 0, dp(6)) })
        val accents = GridLayout(this).apply { columnCount = 5 }
        listOf(Color.rgb(0,103,192), Color.rgb(139,92,246), Color.rgb(0,153,119), Color.rgb(220,70,80), Color.rgb(225,135,20)).forEach { color ->
            val swatch = View(this).apply { background = GradientDrawable().apply { setColor(color); shape = GradientDrawable.OVAL; setStroke(dp(if (accent == color) 3 else 1), if (accent == color) ink else Color.argb(100,255,255,255)) }; setOnClickListener { accent = color; savePreferences(); buildDesktop(); showPersonalization() } }
            accents.addView(swatch, GridLayout.LayoutParams().apply { width = dp(34); height = dp(34); setMargins(dp(8), dp(4), dp(8), dp(4)) })
        }
        box.addView(accents)
        showDesktopWindow("Personalização", box, .72f, .70f)
    }

    /** Frameless Android dialog replacement: a desktop-style window rendered inside the launcher. */
    private fun showDesktopWindow(title: String, content: View, widthFraction: Float, heightFraction: Float) {
        closeContextMenu()
        val shade = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(112, 0, 0, 0))
            isClickable = true
            setOnClickListener { closeDesktopWindow(this) }
            elevation = dp(24).toFloat()
        }
        val window = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(if (darkMode) Color.rgb(30, 30, 30) else Color.rgb(248, 249, 251), 9)
            clipToOutline = true
            elevation = dp(28).toFloat()
            isClickable = true
            setOnClickListener { }
        }
        val titlebar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(6), 0)
            background = rounded(if (darkMode) Color.rgb(38, 38, 38) else Color.rgb(244, 246, 249), 0)
        }
        titlebar.addView(label(title, 13f, ink, Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(0, dp(42), 1f))
        var restoreChip: View? = null
        titlebar.addView(textButton("—", 16f, ink) {
            window.visibility = View.GONE
            if (restoreChip == null) {
                val chip = textButton("▢  $title", 12f, ink) {
                    window.visibility = View.VISIBLE
                    restoreChip?.let { (it.parent as? ViewGroup)?.removeView(it) }
                    restoreChip = null
                }.apply { background = rounded(if (darkMode) Color.rgb(45, 55, 70) else Color.rgb(235, 240, 247), 8); elevation = dp(32).toFloat(); setPadding(dp(12), dp(8), dp(12), dp(8)) }
                root.addView(chip, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { leftMargin = dp(12); bottomMargin = dp(72) })
                restoreChip = chip
            }
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        titlebar.addView(textButton("□", 14f, ink) {
            val lp = window.layoutParams as FrameLayout.LayoutParams
            if (lp.width == -1 && lp.height == -1) {
                lp.width = (resources.displayMetrics.widthPixels * widthFraction).toInt()
                lp.height = (resources.displayMetrics.heightPixels * heightFraction).toInt()
                lp.gravity = Gravity.CENTER
            } else {
                lp.width = -1; lp.height = -1; lp.gravity = Gravity.FILL
            }
            window.layoutParams = lp
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        titlebar.addView(textButton("✕", 16f, ink) { closeDesktopWindow(shade) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        window.addView(titlebar, LinearLayout.LayoutParams(-1, dp(42)))
        if (content.parent is ViewGroup) (content.parent as ViewGroup).removeView(content)
        content.background = rounded(if (darkMode) Color.rgb(30, 30, 30) else Color.rgb(248, 249, 251), 0)
        window.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        val w = (resources.displayMetrics.widthPixels * widthFraction).toInt().coerceAtLeast(dp(320))
        val h = (resources.displayMetrics.heightPixels * heightFraction).toInt().coerceAtLeast(dp(260))
        shade.addView(window, FrameLayout.LayoutParams(w, h, Gravity.CENTER))
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))
        desktopWindows.add(shade)
        shade.setOnKeyListener { _, keyCode, event -> if (keyCode == KeyEvent.KEYCODE_ESCAPE && event.action == KeyEvent.ACTION_UP) { closeDesktopWindow(shade); true } else false }
        shade.isFocusableInTouchMode = true
        shade.requestFocus()
        // Drag the window using the title bar, as in a desktop environment.
        var downX = 0f; var downY = 0f; var startX = 0f; var startY = 0f
        titlebar.setOnTouchListener { _, event ->
            val lp = window.layoutParams as FrameLayout.LayoutParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = lp.leftMargin.toFloat(); startY = lp.topMargin.toFloat(); true }
                MotionEvent.ACTION_MOVE -> { if (lp.gravity != Gravity.FILL) { lp.gravity = Gravity.TOP or Gravity.START; lp.leftMargin = (startX + event.rawX - downX).toInt().coerceIn(0, (resources.displayMetrics.widthPixels - window.width).coerceAtLeast(0)); lp.topMargin = (startY + event.rawY - downY).toInt().coerceIn(0, (resources.displayMetrics.heightPixels - window.height).coerceAtLeast(0)); window.layoutParams = lp }; true }
                else -> false
            }
        }
    }

    private fun closeDesktopWindow(view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
        desktopWindows.remove(view)
    }

    private fun showContextMenu(items: List<Pair<String, () -> Unit>>) {
        closeContextMenu()
        val menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(if (darkMode) Color.rgb(43, 43, 43) else Color.rgb(250, 250, 250)); cornerRadius = dp(8).toFloat(); setStroke(dp(1), if (darkMode) Color.rgb(72,72,72) else Color.rgb(218,220,224)) }
            elevation = dp(30).toFloat(); setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        items.forEach { (name, action) ->
            val row = TextView(this).apply {
                text = name; textSize = 13f; setTextColor(ink); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(24), 0); minHeight = dp(38); isClickable = true; isFocusable = true
                background = rounded(Color.TRANSPARENT, 4)
                setOnClickListener { closeContextMenu(); action() }
                setOnHoverListener { v, e -> if (e.action == MotionEvent.ACTION_HOVER_ENTER) v.setBackgroundColor(if (darkMode) Color.rgb(62,62,62) else Color.rgb(230,240,250)); if (e.action == MotionEvent.ACTION_HOVER_EXIT) v.background = rounded(Color.TRANSPARENT, 4); false }
            }
            menu.addView(row, LinearLayout.LayoutParams(dp(245), -2))
        }
        val frame = FrameLayout(this)
        frame.setOnClickListener { closeContextMenu() }
        frame.addView(menu, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(frame, FrameLayout.LayoutParams(-1, -1))
        contextMenuView = frame
    }

    private fun closeContextMenu() {
        contextMenuView?.let { (it.parent as? ViewGroup)?.removeView(it) }
        contextMenuView = null
    }

    private fun showShortcutContextMenu(title: String, action: () -> Unit, anchor: View = root) {
        showContextMenu(listOf(
            "Abrir" to action,
            "Personalizar" to { showPersonalization() },
            "Atualizar área de trabalho" to { buildDesktop() },
            "Propriedades" to { showInfoWindow(title, "Atalho do Shinigami Desktop. O acesso aos arquivos e aplicativos é controlado pelo Android.") }
        ))
    }

    private fun showAppContextMenu(name: String, intent: Intent, anchor: View = root) {
        showContextMenu(listOf(
            "Abrir" to { launchIntent(intent) },
            "Informações do aplicativo" to {
                val pkg = intent.component?.packageName
                try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) } catch (_: Exception) { openSettings() }
            },
            "Propriedades" to { showInfoWindow(name, "Aplicativo Android instalado. O ícone e as permissões são fornecidos pelo Android.") }
        ))
    }

    private fun showSimpleContextMenu(title: String, action: () -> Unit, anchor: View = root) {
        showContextMenu(listOf(
            "Abrir" to action,
            "Propriedades" to { showInfoWindow(title, "Item do Shinigami Desktop. Algumas operações dependem das permissões fornecidas pelo Android.") }
        ))
    }

    private fun showInfoWindow(title: String, message: String) {
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(18), dp(22), dp(18)); background = rounded(if (darkMode) Color.rgb(30,30,30) else Color.rgb(248,249,251), 0) }
        body.addView(label(message, 14f, ink, Gravity.START), LinearLayout.LayoutParams(-1, 0, 1f))
        body.addView(textButton("OK", 13f, accent) { desktopWindows.lastOrNull()?.let { closeDesktopWindow(it) } }.apply { gravity = Gravity.END; setPadding(dp(24), dp(10), dp(24), dp(10)) })
        showDesktopWindow(title, body, .50f, .38f)
    }

    private fun savePreferences() {
        getSharedPreferences("desktop_preferences", MODE_PRIVATE).edit()
            .putBoolean("dark_mode", darkMode)
            .putInt("wallpaper", wallpaperChoice)
            .putBoolean("taskbar_left", leftAlignedTaskbar)
            .putInt("accent", accent)
            .apply()
    }

    private fun showDesktopMenu() {
        showContextMenu(listOf(
            "Exibir  ›" to { showContextMenu(listOf("Ícones grandes" to { Toast.makeText(this, "Tamanho dos ícones padrão", Toast.LENGTH_SHORT).show() }, "Ícones médios" to { Toast.makeText(this, "Tamanho dos ícones padrão", Toast.LENGTH_SHORT).show() }, "Organizar ícones automaticamente" to { Toast.makeText(this, "Organização automática ativada", Toast.LENGTH_SHORT).show() })) },
            "Atualizar" to { buildDesktop(); Toast.makeText(this, "Área de trabalho atualizada", Toast.LENGTH_SHORT).show() },
            "Novo  ›" to { showContextMenu(listOf("Pasta" to { Toast.makeText(this, "Criar pastas pelo Explorador de Arquivos", Toast.LENGTH_SHORT).show() }, "Atalho" to { showApps() }, "Documento de texto" to { openDocumentPicker("text/plain", "Criar ou selecionar documento") })) },
            "Configurações de exibição" to { try { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } catch (_: Exception) { openSettings() } },
            "Personalizar" to { showPersonalization() }
        ))
    }

    private fun showSearch() {
        val input = EditText(this).apply { hint = "Pesquisar aplicativos ou na Web"; maxLines = 1; setHorizontallyScrolling(true) }
        AlertDialog.Builder(this).setTitle("Pesquisar").setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Pesquisar") { _, _ ->
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) {
                val app = launchableApps().firstOrNull { it.first.contains(q, true) }
                if (app != null) launchIntent(app.second) else openBrave("https://search.brave.com/search?q=" + Uri.encode(q))
            }
        }.show()
    }

    private fun showPowerMenu() {
        AlertDialog.Builder(this).setTitle("Opções de energia").setItems(arrayOf("Bloquear tela", "Suspender / tela de bloqueio", "Configurações de segurança", "Cancelar")) { _, which ->
            when (which) { 0, 1 -> try { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) } catch (_: Exception) { openSettings() }; 2 -> startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }
        }.show()
    }

    private fun showDeviceInfo() {
        AlertDialog.Builder(this).setTitle("Este dispositivo").setMessage("Shinigami Desktop\nLauncher para Android com interface inspirada no Windows 11.\n\nPara configurações completas do tablet, abra Configurações do Android.").setPositiveButton("Configurações") { _, _ -> openSettings() }.setNegativeButton("Fechar", null).show()
    }

    private fun showRecycleBin() {
        AlertDialog.Builder(this).setTitle("Lixeira").setMessage("A lixeira do Windows não existe no Android. Seus arquivos continuam nos aplicativos de arquivos do dispositivo.").setPositiveButton("Abrir arquivos") { _, _ -> openFiles() }.setNegativeButton("Fechar", null).show()
    }

    private fun openBrave(url: String) {
        closeStart()
        val uri = Uri.parse(url)
        try { startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.brave.browser")) }
        catch (_: ActivityNotFoundException) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
            catch (_: Exception) {
                AlertDialog.Builder(this).setTitle("Brave não encontrado").setMessage("Instale o Brave para usá-lo como navegador principal.").setPositiveButton("Abrir Play Store") { _, _ -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.brave.browser"))) } catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.brave.browser"))) } }.setNegativeButton("Agora não", null).show()
            }
        }
    }

    private fun openEdge(url: String) {
        closeStart()
        val uri = Uri.parse(url)
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage("com.microsoft.emmx"))
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            } catch (_: Exception) {
                AlertDialog.Builder(this)
                    .setTitle("Microsoft Edge não encontrado")
                    .setMessage("Instale o Microsoft Edge para usá-lo no Shinigami Desktop.")
                    .setPositiveButton("Abrir Play Store") { _, _ ->
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.microsoft.emmx"))) }
                        catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.microsoft.emmx"))) }
                    }
                    .setNegativeButton("Agora não", null)
                    .show()
            }
        }
    }

    private fun openFiles() {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(14)); background = panelBackground(22) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("📁", 27f, accent, Gravity.CENTER), LinearLayout.LayoutParams(dp(42), dp(44)))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(label("Explorador de Arquivos", 21f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD })
        heading.addView(label("Acesso rápido às pastas do tablet", 11f, if (darkMode) Color.LTGRAY else Color.DKGRAY, Gravity.START))
        head.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(textButton("✕", 19f, ink) { }.apply { visibility = View.GONE }, LinearLayout.LayoutParams(dp(30), dp(38)))
        outer.addView(head)
        val search = EditText(this).apply { hint = "Pesquisar arquivos (abre o seletor do Android)"; textSize = 12f; maxLines = 1; setTextColor(ink); setHintTextColor(Color.GRAY); background = rounded(surface2, 12); setPadding(dp(12), 0, dp(12), 0) }
        outer.addView(search, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(12); bottomMargin = dp(14) })
        outer.addView(label("Acesso rápido", 14f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(dp(2), 0, 0, dp(8)) })
        val scroll = ScrollView(this)
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        data class FolderItem(val icon: String, val name: String, val description: String, val mime: String?)
        val folders = listOf(
            FolderItem("⬇", "Downloads", "Arquivos baixados", null),
            FolderItem("▤", "Documentos", "PDFs e documentos", "application/*"),
            FolderItem("▧", "Imagens", "Fotos e imagens", "image/*"),
            FolderItem("♫", "Música", "Arquivos de áudio", "audio/*"),
            FolderItem("▶", "Vídeos", "Vídeos e filmes", "video/*"),
            FolderItem("▣", "Este dispositivo / pastas", "Escolher uma pasta para navegar", "TREE")
        )
        folders.forEach { folder ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(10), dp(8))
                background = rounded(surface2, 12); isClickable = true; isFocusable = true
                setOnClickListener { if (folder.mime == "TREE") openFolderTree() else openDocumentPicker(folder.mime ?: "*/*", folder.name) }
                setOnLongClickListener { showSimpleContextMenu(folder.name, { if (folder.mime == "TREE") openFolderTree() else openDocumentPicker(folder.mime ?: "*/*", folder.name) }, this); true }
                setOnContextClickListener { showSimpleContextMenu(folder.name, { if (folder.mime == "TREE") openFolderTree() else openDocumentPicker(folder.mime ?: "*/*", folder.name) }, this); true }
            }
            row.addView(label(folder.icon, 23f, accent, Gravity.CENTER), LinearLayout.LayoutParams(dp(42), dp(44)))
            val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            textCol.addView(label(folder.name, 13f, ink, Gravity.START).apply { typeface = Typeface.DEFAULT_BOLD })
            textCol.addView(label(folder.description, 11f, if (darkMode) Color.LTGRAY else Color.DKGRAY, Gravity.START).apply { setPadding(0, dp(3), 0, 0) })
            row.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label("›", 23f, ink, Gravity.CENTER), LinearLayout.LayoutParams(dp(22), dp(42)))
            rows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        scroll.addView(rows)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        outer.addView(textButton("Abrir seletor completo de arquivos  ›", 13f, accent) { openDocumentPicker("*/*", "Todos os arquivos") }.apply { gravity = Gravity.START; setPadding(dp(2), dp(12), dp(2), dp(4)) })
        showDesktopWindow("Explorador de Arquivos", outer, .84f, .82f)
    }

    private fun openDocumentPicker(mimeType: String, title: String) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = mimeType }
        try { startActivity(Intent.createChooser(intent, title)) } catch (_: Exception) { openSettings() }
    }

    private fun openFolderTree() {
        try { startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)) } catch (_: Exception) { openDocumentPicker("*/*", "Pastas e arquivos") }
    }

    private fun openNetworkSettings() {
        try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (_: Exception) { openSettings() }
    }

    private fun openSettings() {
        try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir as configurações.", Toast.LENGTH_SHORT).show() }
    }

    private fun launchableApps(): List<Pair<String, Intent>> {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val infos = if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(query, PackageManager.ResolveInfoFlags.of(0)) else packageManager.queryIntentActivities(query, 0)
        return infos.mapNotNull { info ->
            val name = info.loadLabel(packageManager)?.toString() ?: return@mapNotNull null
            val intent = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName) ?: return@mapNotNull null
            name to intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }.distinctBy { it.first }.sortedBy { it.first.lowercase(Locale.getDefault()) }
    }

    private fun launchIntent(intent: Intent) { try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir o aplicativo.", Toast.LENGTH_SHORT).show() } }
    private fun closeStart() { startPanel?.let { root.removeView(it) }; startPanel = null }
    private fun closeApps() { appPanel?.let { root.removeView(it) }; appPanel = null }
    private fun closeQuickPanel() { quickPanel?.let { root.removeView(it) }; quickPanel = null }

    private fun textButton(text: String, size: Float, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; isClickable = true; isFocusable = true; setOnClickListener { action() }; setPadding(dp(5), dp(2), dp(5), dp(2))
    }
    private fun label(text: String, size: Float, color: Int, gravity: Int): TextView = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); this.gravity = gravity }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun panelBackground(radius: Int) = GradientDrawable().apply {
        setColor(if (darkMode) Color.argb(246, 29, 40, 55) else Color.argb(247, 244, 248, 253))
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), if (darkMode) Color.argb(65,255,255,255) else Color.argb(170,255,255,255))
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun clockText(): String = SimpleDateFormat("HH:mm\ndd/MM/yyyy", Locale("pt", "BR")).format(Date())
    private fun adjust(color: Int, delta: Int): Int = Color.rgb((Color.red(color) + delta).coerceIn(0,255), (Color.green(color) + delta).coerceIn(0,255), (Color.blue(color) + delta).coerceIn(0,255))

    private inner class WallpaperView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat(); val h = height.toFloat()
            val palettes = when (wallpaperChoice) {
                1 -> intArrayOf(Color.rgb(7, 40, 62), Color.rgb(15, 103, 117), Color.rgb(9, 28, 48))
                2 -> intArrayOf(Color.rgb(12, 18, 42), Color.rgb(39, 48, 86), Color.rgb(8, 14, 29))
                else -> intArrayOf(Color.rgb(7, 25, 53), Color.rgb(0, 83, 147), Color.rgb(4, 20, 44))
            }
            paint.shader = LinearGradient(0f, 0f, w, h, palettes, null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, 0f, w, h, paint)
            paint.shader = null
            // Abstract luminous folded bloom, drawn locally (no network images or ad SDKs).
            val cx = w * .62f; val cy = h * .49f
            paint.shader = RadialGradient(cx, cy, maxOf(w,h)*.66f, intArrayOf(Color.argb(120, 70, 180, 255), Color.argb(20, 22, 104, 210), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, maxOf(w,h)*.66f, paint); paint.shader = null
            val path = Path().apply { moveTo(cx - w*.31f, cy + h*.08f); cubicTo(cx - w*.18f, cy - h*.34f, cx + w*.05f, cy - h*.29f, cx + w*.25f, cy - h*.08f); cubicTo(cx + w*.08f, cy + h*.02f, cx - w*.05f, cy + h*.13f, cx - w*.31f, cy + h*.08f); close() }
            paint.shader = LinearGradient(cx-w*.3f, cy-h*.2f, cx+w*.2f, cy+h*.2f, intArrayOf(Color.argb(110, 40, 160, 255), Color.argb(35, 20, 100, 210)), null, Shader.TileMode.CLAMP)
            canvas.drawPath(path, paint); paint.shader = null
            paint.color = Color.argb(28, 255, 255, 255)
            for (i in 0..7) canvas.drawCircle(w*(.12f+i*.11f), h*(.14f+(i%3)*.16f), dp(1).toFloat(), paint)
        }
    }

    private class Watcher(private val onText: (String) -> Unit) : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onText(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: Editable?) {}
    }
}
