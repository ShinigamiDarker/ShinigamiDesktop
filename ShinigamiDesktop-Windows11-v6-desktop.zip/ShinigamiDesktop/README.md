# Shinigami Desktop — edição desktop 0.4.0

Launcher Android para tablets, com interface inspirada no Windows 11. Esta versão redesenha a área de trabalho e os painéis para se aproximarem mais da linguagem visual do Windows 11: barra de tarefas centralizada, botão Iniciar com logotipo em quatro quadrantes, caixa de pesquisa, painel Iniciar com aplicativos fixados e recomendados, bandeja do sistema, configurações rápidas e uma tela de personalização.

## O que mudou nesta versão
- Papel de parede abstrato azul inspirado no estilo “Bloom”, desenhado localmente e sem depender de imagens externas.
- Barra de tarefas translúcida com alinhamento central ou à esquerda.
- Menu Iniciar redesenhado com busca, atalhos fixados, seção de recomendados e opções de energia.
- Lista de aplicativos com ícones reais dos aplicativos instalados, quando o Android os disponibiliza.
- Painel de configurações rápidas com atalhos para rede, Bluetooth e Configurações.
- Personalização de papel de parede, modo claro/escuro, alinhamento da barra e cor de destaque.
- Ícone próprio do aplicativo Shinigami Desktop, com identidade visual azul e vermelha.
- Menus de contexto escuros desenhados pelo launcher, com submenus iniciais para Exibir e Novo; clique direito do mouse e toque prolongado nos itens suportados.
- Janelas internas próprias para Explorador, Configurações e Personalização, com barra de título, minimizar/restaurar, maximizar/restaurar e arrastar pela barra de título.
- Atalhos de teclado: Meta/Windows + E abre o Explorador, Meta + I abre Configurações, Meta + S abre Pesquisa e Meta + D fecha painéis.
- Explorador visual com acesso rápido a Downloads, documentos, imagens, música, vídeos e seleção de pastas; o acesso real respeita o seletor de documentos e as permissões do Android.
- Página de Configurações redesenhada, com categorias e pesquisa; itens que dependem do sistema encaminham para as configurações reais do Android.
- Preferências de tema, papel de parede, cor e alinhamento persistem entre aberturas.
- Menu de contexto da área de trabalho e relógio/data na barra de tarefas.
- Brave priorizado para abrir pesquisas e links. Se não estiver instalado, o launcher tenta abrir um navegador disponível.
- Sem SDK de anúncios, publicidade própria ou telemetria própria.

## Compilar o APK pelo GitHub
1. Coloque a pasta `ShinigamiDesktop` na raiz do repositório ou use o workflow que extrai este ZIP.
2. Abra **Actions** e execute **Build Shinigami Desktop APK**.
3. Quando a execução terminar com sucesso, abra-a e baixe o artifact `ShinigamiDesktop-debug-apk`.
4. Instale o APK no tablet.
5. Em Configurações do Android → Aplicativos padrão → App de início, escolha **Shinigami Desktop**.

## Observação importante
É um launcher Android que reproduz a aparência e alguns fluxos comuns do Windows 11; não é o sistema operacional Windows. Aplicativos continuam sendo aplicativos Android e algumas ações (energia, rede, arquivos e brilho) são encaminhadas às configurações ou APIs do Android. A aparência pode variar conforme a versão do Android, densidade de tela e tamanho do tablet.


## Limites importantes e controles
O Shinigami Desktop é um launcher Android, não pode substituir o Android por Windows nem executar o Explorador de Arquivos, o shell ou as configurações internas do Windows. O Android controla as permissões de arquivos, as configurações de sistema e o lançamento de aplicativos. O menu de contexto responde ao botão direito do mouse quando o dispositivo/versão Android entrega esse evento; no touch, use toque prolongado. A fidelidade visual e os recursos de janelas, arrastar e soltar, fixação real e comportamento de duplo clique ainda exigem etapas adicionais.
