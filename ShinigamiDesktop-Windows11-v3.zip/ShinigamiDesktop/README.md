# Shinigami Desktop — edição visual 0.2.0

Launcher Android para tablets, com interface inspirada no Windows 11. Esta versão redesenha a área de trabalho e os painéis para se aproximarem mais da linguagem visual do Windows 11: barra de tarefas centralizada, botão Iniciar com logotipo em quatro quadrantes, caixa de pesquisa, painel Iniciar com aplicativos fixados e recomendados, bandeja do sistema, configurações rápidas e uma tela de personalização.

## O que mudou nesta versão
- Papel de parede abstrato azul inspirado no estilo “Bloom”, desenhado localmente e sem depender de imagens externas.
- Barra de tarefas translúcida com alinhamento central ou à esquerda.
- Menu Iniciar redesenhado com busca, atalhos fixados, seção de recomendados e opções de energia.
- Lista de aplicativos com ícones reais dos aplicativos instalados, quando o Android os disponibiliza.
- Painel de configurações rápidas com atalhos para rede, Bluetooth e Configurações.
- Personalização de papel de parede, modo claro/escuro, alinhamento da barra e cor de destaque.
- Menu de contexto da área de trabalho e relógio/data na barra de tarefas.
- Brave priorizado para abrir pesquisas e links. Se não estiver instalado, o launcher tenta abrir um navegador disponível.
- Sem SDK de anúncios, publicidade própria ou telemetria própria.

## Compilar o APK pelo GitHub
1. Coloque a pasta `ShinigamiDesktop` na raiz do repositório ou use o workflow que extrai este ZIP.
2. Abra **Actions** e execute **Build Shinigami Desktop APK**.
3. Quando a execução terminar com sucesso, abra-a e baixe o artifact `ShinigamiDesktop-debug-apk`.
4. Instale o APK no tablet.
5. Em Configurações do Android → Aplicativos padrão → App de início, escolha **Shinigami Desktop**.

## Observação importante
É um launcher Android que reproduz a aparência e alguns fluxos comuns do Windows 11; não é o sistema operacional Windows. Aplicativos continuam sendo aplicativos Android e algumas ações (energia, rede, arquivos e brilho) são encaminhadas às configurações ou APIs do Android. A aparência pode variar conforme a versão do Android, densidade de tela e tamanho do tablet.
