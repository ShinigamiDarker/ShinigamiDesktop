# Shinigami Desktop — Android Launcher

Launcher Android em estilo Windows 11, pensado para tablets. Versão inicial 0.1.0.

## Recursos incluídos
- Atividade Android registrada como HOME para poder ser escolhida como launcher padrão.
- Área de trabalho com atalhos, barra de tarefas, menu Iniciar e relógio.
- Lista pesquisável de aplicativos instalados.
- Atalhos para Arquivos, Configurações e Brave.
- Busca que abre aplicativos locais ou pesquisa no Brave Search.
- Sem SDK de anúncios, anúncios próprios, telemetria própria ou chamadas de rede dentro do launcher.
- Workflow GitHub Actions para compilar e disponibilizar o APK como Artifact.

## Compilar APK no GitHub
1. Envie o conteúdo desta pasta para um repositório GitHub (branch `main` ou `master`).
2. Abra **Actions** e execute **Build Shinigami Desktop APK** (ou faça push).
3. Abra a execução concluída e baixe o artifact `ShinigamiDesktop-debug-apk`.
4. Instale `app-debug.apk` no tablet.
5. Em Configurações do Android → Aplicativos padrão → App de início, escolha **Shinigami Desktop**.

## Brave
O launcher tenta abrir links diretamente no pacote `com.brave.browser`. Se não estiver instalado, abre o navegador disponível ou oferece a Play Store. Para definir o Brave como navegador padrão do sistema, abra o menu Configurações → Definir navegador padrão e selecione Brave.

## Limites desta versão
Esta é a base funcional inicial, não uma cópia completa do Windows nem um sistema operacional. Aplicativos Android externos continuam abrindo nas próprias atividades do Android; janelas flutuantes reais exigiriam APIs e permissões adicionais. O explorador usa o seletor de documentos do Android para manter acesso aos arquivos mediado pelo sistema.
