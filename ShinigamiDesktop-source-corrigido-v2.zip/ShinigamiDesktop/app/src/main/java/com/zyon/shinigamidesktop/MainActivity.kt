package com.zyon.shinigamidesktop

import android.app.Activity
import android.app.AlertDialog
import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val navy = Color.rgb(15, 24, 42)
    private val panel = Color.argb(238, 27, 42, 65)
    private val blue = Color.rgb(76, 139, 245)
    private lateinit var root: FrameLayout
    private lateinit var desktop: LinearLayout
    private var startPanel: View? = null
    private var appPanel: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 20, 35)
        window.navigationBarColor = Color.rgb(16, 25, 42)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING)
        buildDesktop()
    }

    override fun onBackPressed() {
        if (startPanel != null) { root.removeView(startPanel); startPanel = null; return }
        if (appPanel != null) { root.removeView(appPanel); appPanel = null; return }
        super.onBackPressed()
    }

    private fun buildDesktop() {
        root = FrameLayout(this)
        root.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(10, 25, 55), Color.rgb(22, 76, 126), Color.rgb(13, 35, 72)))
        setContentView(root)

        // Soft, abstract Windows-like bloom made from native shapes; no remote images or ad SDKs.
        val glow = View(this)
        glow.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.argb(90, 86, 167, 255), Color.argb(5, 24, 85, 170))).apply {
            cornerRadius = dp(260).toFloat()
        }
        val glowLp = FrameLayout.LayoutParams(dp(520), dp(330), Gravity.CENTER)
        glowLp.leftMargin = dp(40)
        root.addView(glow, glowLp)

        desktop = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(76)) }
        root.addView(desktop, FrameLayout.LayoutParams(-1, -1))

        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
        desktop.addView(topRow, LinearLayout.LayoutParams(-1, -2))
        addDesktopShortcut(topRow, "📁", "Arquivos") { openFiles() }
        addDesktopShortcut(topRow, "🦁", "Brave") { openBrave("https://search.brave.com") }
        addDesktopShortcut(topRow, "⚙️", "Configurações") { openSettings() }
        addDesktopShortcut(topRow, "▦", "Aplicativos") { showApps() }

        val hint = TextView(this).apply {
            text = "Shinigami Desktop\nSeu tablet, em modo desktop"
            setTextColor(Color.argb(220, 255, 255, 255)); textSize = 18f
            gravity = Gravity.CENTER; setLineSpacing(dp(5).toFloat(), 1f)
        }
        val hintLp = FrameLayout.LayoutParams(-1, -2, Gravity.CENTER)
        hintLp.bottomMargin = dp(28)
        root.addView(hint, hintLp)

        val taskbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.argb(238, 22, 32, 49), 22)
            setPadding(dp(10), dp(7), dp(10), dp(7))
        }
        val taskLp = FrameLayout.LayoutParams(-2, dp(58), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        taskLp.setMargins(dp(12), 0, dp(12), dp(12))
        root.addView(taskbar, taskLp)

        val start = textButton("⊞", 28f, Color.WHITE) { toggleStart() }
        taskbar.addView(start, LinearLayout.LayoutParams(dp(48), -1))
        val search = textButton("Pesquisar", 14f, Color.WHITE) { showSearch() }
        search.background = rounded(Color.argb(90, 255, 255, 255), 16)
        val searchLp = LinearLayout.LayoutParams(dp(126), -1); searchLp.setMargins(dp(5), 0, dp(5), 0)
        taskbar.addView(search, searchLp)
        addTaskIcon(taskbar, "📁", "Arquivos") { openFiles() }
        addTaskIcon(taskbar, "🦁", "Brave") { openBrave("https://search.brave.com") }
        addTaskIcon(taskbar, "▦", "Todos os aplicativos") { showApps() }
        val spacer = View(this); taskbar.addView(spacer, LinearLayout.LayoutParams(dp(12), 1))
        val clock = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; gravity = Gravity.CENTER; text = clockText() }
        taskbar.addView(clock, LinearLayout.LayoutParams(dp(74), -1))
        clock.postDelayed(object : Runnable { override fun run() { if (!isFinishing) { clock.text = clockText(); clock.postDelayed(this, 30_000) } } }, 30_000)
    }

    private fun addDesktopShortcut(parent: LinearLayout, glyph: String, label: String, action: () -> Unit) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(6), dp(5), dp(8)); isClickable = true; isFocusable = true; setOnClickListener { action() } }
        val icon = TextView(this).apply { text = glyph; textSize = 31f; gravity = Gravity.CENTER }
        col.addView(icon, LinearLayout.LayoutParams(dp(58), dp(54)))
        val name = TextView(this).apply { text = label; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 2 }
        col.addView(name, LinearLayout.LayoutParams(dp(76), -2))
        parent.addView(col, LinearLayout.LayoutParams(dp(82), dp(94)))
    }
    private fun addTaskIcon(parent: LinearLayout, glyph: String, label: String, action: () -> Unit) {
        parent.addView(textButton(glyph, 22f, Color.WHITE, action).apply { contentDescription = label }, LinearLayout.LayoutParams(dp(44), -1))
    }

    private fun toggleStart() {
        if (startPanel != null) { root.removeView(startPanel); startPanel = null; return }
        appPanel?.let { root.removeView(it); appPanel = null }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(16)); background = rounded(Color.argb(247, 24, 36, 55), 24) }
        val lp = FrameLayout.LayoutParams(dp(360), dp(430), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = dp(80)
        root.addView(box, lp); startPanel = box
        box.addView(TextView(this).apply { text = "Iniciar"; textSize = 24f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) })
        val input = EditText(this).apply { hint = "Pesquisar aplicativos"; setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); background = rounded(Color.argb(65,255,255,255), 12); setPadding(dp(12), 0, dp(12), 0) }
        val ilp = LinearLayout.LayoutParams(-1, dp(46)); ilp.setMargins(0, dp(14), 0, dp(12)); box.addView(input, ilp)
        val grid = GridLayout(this).apply { columnCount = 3 }
        box.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        listOf(Triple("🦁", "Brave", { openBrave("https://search.brave.com") }), Triple("📁", "Arquivos", { openFiles() }), Triple("⚙️", "Configurações", { openSettings() }), Triple("▦", "Todos", { showApps() }), Triple("🌐", "Internet", { openBrave("https://search.brave.com") }), Triple("⏻", "Desligar", { showPowerMenu() })).forEach { (glyph, title, action) ->
            val item = textButton("$glyph\n$title", 14f, Color.WHITE, action).apply { background = rounded(Color.argb(45,255,255,255), 14); setPadding(dp(4), dp(6), dp(4), dp(6)) }
            val glp = GridLayout.LayoutParams().apply { width = 0; height = dp(76); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(3), dp(3), dp(3), dp(3)) }
            grid.addView(item, glp)
        }
        input.addTextChangedListener(SimpleWatcher { query ->
            grid.removeAllViews()
            val matches = launchableApps().filter { it.first.contains(query, true) }.take(9)
            matches.forEach { (name, intent) ->
                val item = textButton("▣\n$name", 13f, Color.WHITE) { launchIntent(intent) }
                val glp = GridLayout.LayoutParams().apply { width = 0; height = dp(70); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(3), dp(3), dp(3), dp(3)) }
                grid.addView(item, glp)
            }
        })
    }

    private fun showApps() {
        startPanel?.let { root.removeView(it); startPanel = null }
        appPanel?.let { root.removeView(it); appPanel = null; return }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(12)); background = rounded(Color.argb(248, 23, 35, 54), 22) }
        val lp = FrameLayout.LayoutParams(if (resources.configuration.screenWidthDp > 700) dp(560) else -1, dp(500), Gravity.CENTER)
        lp.setMargins(dp(16), dp(16), dp(16), dp(16)); root.addView(box, lp); appPanel = box
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        head.addView(TextView(this).apply { text = "Aplicativos"; textSize = 22f; setTextColor(Color.WHITE); setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(textButton("✕", 20f, Color.WHITE) { root.removeView(box); appPanel = null }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head)
        val input = EditText(this).apply { hint = "Filtrar aplicativos"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); background = rounded(Color.argb(55,255,255,255), 12); setPadding(dp(12), 0, dp(12), 0) }
        val inpLp = LinearLayout.LayoutParams(-1, dp(44)); inpLp.setMargins(0, dp(12), 0, dp(10)); box.addView(input, inpLp)
        val list = ListView(this); box.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        fun refresh(q: String) {
            val apps = launchableApps().filter { it.first.contains(q, true) }
            list.adapter = object : ArrayAdapter<Pair<String, Intent>>(this, android.R.layout.simple_list_item_1, apps) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    return (convertView as? TextView ?: TextView(this@MainActivity).apply { setPadding(dp(14), dp(12), dp(8), dp(12)); textSize = 16f; setTextColor(Color.WHITE) }).apply { text = "▣   ${apps[position].first}"; setBackgroundColor(Color.TRANSPARENT) }
                }
            }
            list.setOnItemClickListener { _, _, position, _ -> launchIntent(apps[position].second) }
        }
        refresh("")
        input.addTextChangedListener(SimpleWatcher { refresh(it) })
    }

    private fun launchableApps(): List<Pair<String, Intent>> {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val infos = if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(query, android.content.pm.PackageManager.ResolveInfoFlags.of(0)) else packageManager.queryIntentActivities(query, 0)
        return infos.mapNotNull { info ->
            val name = info.loadLabel(packageManager)?.toString() ?: return@mapNotNull null
            val intent = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName) ?: return@mapNotNull null
            name to intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }.distinctBy { it.first }.sortedBy { it.first.lowercase(Locale.getDefault()) }
    }

    private fun openBrave(url: String) {
        startPanel?.let { root.removeView(it); startPanel = null }
        val uri = Uri.parse(url)
        val brave = Intent(Intent.ACTION_VIEW, uri).setPackage("com.brave.browser")
        try { startActivity(brave) } catch (_: ActivityNotFoundException) {
            try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {
                AlertDialog.Builder(this).setTitle("Brave não encontrado").setMessage("Instale o Brave e tente novamente.")
                    .setPositiveButton("Abrir Play Store") { _, _ -> startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.brave.browser"))) }
                    .setNegativeButton("Agora não", null).show()
            }
        }
    }

    private fun openFiles() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        try { startActivity(intent) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    private fun openSettings() {
        val options = arrayOf("Configurações do Android", "Definir navegador padrão", "Informações do Shinigami Desktop")
        AlertDialog.Builder(this).setTitle("Configurações").setItems(options) { _, which ->
            when (which) {
                0 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                1 -> try { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
                2 -> AlertDialog.Builder(this).setTitle("Shinigami Desktop 0.1.0").setMessage("Launcher Android inspirado no Windows 11. Sem SDK de anúncios nem telemetria própria.").setPositiveButton("OK", null).show()
            }
        }.show()
    }

    private fun showSearch() {
        val input = EditText(this).apply { hint = "Pesquisar na web ou aplicativos"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Pesquisar").setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Buscar") { _, _ ->
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) {
                val app = launchableApps().firstOrNull { it.first.contains(q, true) }
                if (app != null) launchIntent(app.second) else openBrave("https://search.brave.com/search?q=" + Uri.encode(q))
            }
        }.show()
    }

    private fun showPowerMenu() {
        AlertDialog.Builder(this).setTitle("Sessão").setItems(arrayOf("Segurança do dispositivo", "Abrir configurações", "Cancelar")) { _, which ->
            when (which) { 0 -> startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)); 1 -> openSettings() }
        }.show()
    }

    private fun launchIntent(intent: Intent) { try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir o aplicativo.", Toast.LENGTH_SHORT).show() } }
    private fun textButton(text: String, size: Float, color: Int, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER; isClickable = true; isFocusable = true; setOnClickListener { action() }
        setPadding(dp(4), dp(2), dp(4), dp(2))
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun clockText(): String = SimpleDateFormat("HH:mm\ndd/MM", Locale("pt", "BR")).format(Date())

    private class SimpleWatcher(val onText: (String) -> Unit) : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onText(s?.toString().orEmpty()) }
        override fun afterTextChanged(s: android.text.Editable?) {}
    }
}
