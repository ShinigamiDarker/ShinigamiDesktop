#!/usr/bin/env python3
"""Hide the entire recommended section in decoded Apktool resources."""
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
text = p.read_text(encoding='utf-8')
# Add visibility=gone to the root view, retaining the rest of the XML unchanged.
m = re.search(r'<([A-Za-z_][\w.]*(?::[\w.]+)?)(\s[^<>]*?)?>', text, re.S)
if not m:
    raise SystemExit(f'Could not find root XML element in {p}')
root_tag = m.group(0)
if re.search(r'android:visibility\s*=', root_tag):
    root_tag = re.sub(r'android:visibility\s*=\s*"[^"]*"', 'android:visibility="gone"', root_tag, count=1)
else:
    root_tag = root_tag[:-1] + ' android:visibility="gone">'
text = text[:m.start()] + root_tag + text[m.end():]
p.write_text(text, encoding='utf-8')
print(f'Patched {p}: root view visibility=gone')
