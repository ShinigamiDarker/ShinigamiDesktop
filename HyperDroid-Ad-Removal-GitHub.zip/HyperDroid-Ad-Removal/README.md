# HyperDroid 2.7 — remover seção de anúncios do menu Iniciar

Este projeto contém o XAPK fornecido e um workflow do GitHub Actions que extrai o APK principal, decodifica os recursos com Apktool, oculta a seção `start_menu_recommended` e recompila/assina um APK de teste.

## Como usar
1. Crie um repositório GitHub e envie os arquivos deste ZIP.
2. No GitHub, abra **Actions** e execute **Build HyperDroid sem recomendações patrocinadas**.
3. Baixe o artefato `HyperDroid-no-recommendations` gerado pelo workflow.

## Importante
- O patch oculta o layout inteiro `start_menu_recommended`, pois é a seção que contém o anúncio na captura. Isso também pode ocultar o título/área de recomendados, não apenas o cartão do anúncio.
- O APK gerado é assinado com uma chave de teste criada durante a execução. Para instalar, talvez seja necessário desinstalar a versão atual do HyperDroid primeiro; isso pode apagar dados locais do app.
- Este workflow não foi executado neste ambiente. A compilação real e a instalação precisam ser verificadas no GitHub/dispositivo.
- O arquivo de entrada é o XAPK original fornecido; os APKs de idioma separados não são incorporados ao APK universal recompilado.
